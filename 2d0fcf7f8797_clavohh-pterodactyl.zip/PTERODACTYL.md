# Hosting on Pterodactyl

The zip you upload is `clavohh-pterodactyl.zip` — the project at the **root** of the
archive (no wrapper folder), so unarchiving it in `/home/container` puts
`index.js`, `package.json`, `helper/` and `sessions/` where the panel expects
them. No `node_modules` and no credentials are inside.

What makes it talk to the website: **one variable**, `NEON_DATABASE_URL`. The
bot polls the same Neon tables the site writes to (`talkless_pairing_requests`,
`talkless_session_submissions`, `talkless_session_imports`) and mirrors state
into `talkless_sessions`. No public URL, no port, no webhook.

## 1. Import the egg (admin, once)

`pterodactyl/egg-clavohh-webdb.json` is a PTDL_v2 egg.

Admin → **Nests** → pick or create a nest (e.g. *Bots*) → **Import Egg** → choose
the JSON → assign it to the nest.

Egg defaults:

| Setting | Value |
| --- | --- |
| Docker image | `ghcr.io/parkervcp/yolks:nodejs_20` (or `nodejs_22`) |
| Startup command | `[ -d node_modules ] || npm install --omit=dev --no-audit --no-fund; node index.js` |
| Stop command | `^C` |
| Startup detection | `Bot running` / `WEBSITE CONNECTED` / `ready - waiting` |

## 2. Create the server

- Egg: **TALKLESS / CLAVOHH - Website Pairing (Neon)**
- Image: **Node.js 20** (minimum for the current Baileys release)
- Memory: **1024 MB** recommended, 512 MB works if you keep one or two numbers
  (`sharp`, `ffmpeg-static` and the TALKLESS pack are heavy)
- Disk: 3 GB
- Allocation: not required. The optional health endpoint uses the `PORT`
  variable inside the container.

## 3. Upload the files

Panel → your server → **File Manager** → `/home/container` → **Upload**
`clavohh-pterodactyl.zip` → right-click it → **Unarchive**.

You should then see `index.js`, `package.json`, `helper/`, `talkless/`,
`schema-neon-website.sql`, `webdb-check.js` at the top level. Delete the zip
afterwards.

> If your panel's upload limit is below 3.4 MB, upload `CLAVINS.zip` instead is
> **not** equivalent — that is the original repo without the website bridge.
> Ask an admin to raise the limit, or upload the files in two parts.

## 4. Fill the Startup variables

Startup tab:

| Variable | Value |
| --- | --- |
| `NEON_DATABASE_URL` | the exact Postgres URL the pairing website uses (`postgresql://…neon.tech/neondb?sslmode=require`) |
| `WEBSITE_URL` | your pairing site |
| `TELEGRAM_TOKEN` | from @BotFather |
| `OWNER_TELEGRAM_ID` | your numeric Telegram id |
| `PORT` | `3001` unless the panel needs something else |

Everything else (GitHub session sync, Paystack, OpenAI) is optional and can stay
empty. If your panel does not expose a variable you need, put it in
`.env` instead — the bot reads `.env` first and panel variables override nothing
already set in the environment, so either route works.

The tables are created automatically on boot. If you prefer to do it by hand,
run `schema-neon-website.sql` in the Neon SQL editor — same statements.

### Connection modes

Either entry point alone is enough, exactly like TALKLESS-XMD:

| `TELEGRAM_TOKEN` | `NEON_DATABASE_URL` | Result |
| --- | --- | --- |
| set | set | Telegram control **and** website pairing |
| set | empty | Telegram only — banner shows `Website: OFF (no database)` |
| empty | set | Website only — banner shows `Telegram: OFF (no token)`, every Telegram handler is registered but nothing is polled and sends are no-ops |
| empty | empty | Prints what is missing and exits with code `1` |

The banner tells you which mode you are in before anything starts:

```
👑 TALKLESS XMD 👑
Telegram: ONLINE
Website : ONLINE
```

## 5. Start and verify

Press **Start** and read the console (rainbow banner + tagged lines):

```
[TALKLESS XMD] [INFO] Pairing loop started (3s interval)
[TALKLESS XMD] [OK]   WEBSITE CONNECTED - Neon ep-xxxx.region.aws.neon.tech ready, waiting for pairing requests
[TALKLESS XMD] [OK]   TELEGRAM – Bot running
```

Colour is forced (`FORCE_COLOR=3`, `chalk.level = 3`), so the panel console shows
the real rainbow even though it is not a TTY. `lolcatjs` is used when installed;
otherwise the same gradient is drawn with `chalk`.

- `WEBSITE CONNECTED` → the site and the bot share a database; open the site and
  request a code.
- `WEBSITE NOT CONNECTED` / `NEON_DATABASE_URL not set` → the URL is wrong, the
  database is paused, or the variable did not reach the process.
- In Telegram, `/webstatus` (owner) prints state, host, waiting rows, loop state
  and the table names.

To test the database in isolation, temporarily set the startup command to
`node webdb-check.js`, start, read the report, then restore the default command.
(The panel console does not accept typed shell commands.)

## 6. What persists

| Path | Contents |
| --- | --- |
| `/home/container/sessions/wa_web_<phone>/creds.json` | numbers paired from the website |
| `/home/container/sessions/wa_<tgId>_<phone>/creds.json` | numbers paired with `/pair` |
| `/home/container/sessions/.backup/` | archived folders from re-pairs, last 3 kept |

Sessions survive restarts and reinstalls of the container. Do **not** delete a
`creds.json` while the device is still linked — archive it (`/delpair` does the
right thing) or the phone keeps sending messages no device can decrypt.

Back them up: download the `sessions` folder from the file manager, or set the
`GITHUB_*` variables to let the bot mirror sessions into a private repo.

## 7. Troubleshooting

| Symptom | Cause / fix |
| --- | --- |
| `SyntaxError` / `ERR_REQUIRE_ESM` on `@whiskeysockets/baileys` | image is Node 18. Switch the server image to **Node.js 20**. |
| `Cannot find module 'pg'` | dependencies were not installed: restart with the default startup command, or check that `package.json` is in `/home/container`. |
| `ENOTFOUND` / `ETIMEDOUT` for the Neon host | wrong host in `NEON_DATABASE_URL`, or the Neon project is suspended. Copy the URL again from Neon → Connection string. |
| `WEBSITE NOT CONNECTED` but the URL is right | the URL still has `?sslmode=require&channel_binding=require`; the bot strips `?…`, that is fine — check for stray quotes or a trailing space. |
| Website code request stays `processing` | the bot is not running, or two servers share the same session folder. One process per number. |
| `This number is already connected.` | the number already has a live socket in this server (website or `/pair`). Remove it first. |
| Reconnect loop, `connection replaced` | the same `sessions/<id>` folder is open in two processes (two servers, or GitHub sync pulling the same session). |
| Container killed, exit code 137 | out of memory. Raise the limit to 1024 MB+ and avoid running many numbers per server. |

## 8. Security

`settings.js` in the uploaded repo still contains **live-looking fallback
credentials** (Telegram token, GitHub token, Paystack keys, Pterodactyl API key).
They are only defaults — set the real values in the Startup tab — but anything
committed is public:

1. Revoke and reissue the Telegram token with @BotFather.
2. Rotate the GitHub token, the Paystack keys and the panel API key.
3. Keep `GITHUB_TOKEN` / `PAYSTACK_SECRET_KEY` in the panel variables, never in
   `settings.js`.
4. Never share `sessions/` — those files are full WhatsApp logins.
