#!/usr/bin/env node
/**
 * TALKLESS XMD – WhatsApp command self-diagnostic
 *
 * Drop this file in the bot root (next to index.js) and run:
 *     node diagnose.js
 *
 * It answers one question: why do WhatsApp commands not respond?
 * Nothing is written outside database/ and the pack's own data dirs.
 */
'use strict';

const path = require('path');
const fs = require('fs');

const ROOT = __dirname;
const results = [];
function line(state, area, msg) {
  const icon = state === 'ok' ? '[ OK ]' : state === 'warn' ? '[WARN]' : '[FAIL]';
  results.push({ state, area, msg });
  console.log(`${icon} ${area.padEnd(14)} ${msg}`);
}

// ─── child mode: load the pack exactly like index.js does, watch for crashes ──
if (process.env.XMD_SELFTEST_CHILD === '1') {
  const sent = [];
  const sock = {
    user: { id: '254700000000:1@s.whatsapp.net' },
    __waNum: '254700000000',
    sendMessage: async (jid, c) => { sent.push(c.text || Object.keys(c)); return { key: { id: 'x' } }; },
    sendPresenceUpdate: async () => {},
    groupMetadata: async () => ({ subject: 'test', participants: [] }),
  };
  const msg = {
    key: { remoteJid: '254711111111@s.whatsapp.net', fromMe: false, id: 'DIAG' },
    message: { conversation: process.env.XMD_TEST_CMD || '.ping' },
  };
  const bridge = require(path.join(ROOT, 'talklessBridge.js'));
  (async () => {
    try { await bridge.handle(sock, msg); } catch (e) { console.log('DISPATCH_THREW ' + e.message); }
    console.log('COMMANDS ' + bridge.count);
    console.log('REPLIES ' + JSON.stringify(sent));
    console.log('ALIVE_AT_DISPATCH');
    // stay alive long enough for the pack's load-time async work to fail/succeed
    setTimeout(() => { console.log('ALIVE_AFTER_20S'); process.exit(0); }, 20000);
  })();
  return;
}

// ─── parent mode ─────────────────────────────────────────────────────────────
console.log('\n=== TALKLESS XMD diagnostic ===\n');

line('ok', 'node', process.version + ' (needs >= 18)');

for (const dir of ['database', path.join('talkless', 'database'), 'sessions']) {
  const abs = path.join(ROOT, dir);
  try {
    fs.mkdirSync(abs, { recursive: true });
    const probe = path.join(abs, '.write-probe');
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    line('ok', 'writable', dir + '/');
  } catch (e) {
    line('fail', 'writable', `${dir}/ NOT writable (${e.code || e.message}) -> command dispatch breaks`);
  }
}

try {
  const cfg = require(path.join(ROOT, 'talkless', 'config.js'));
  line('ok', 'prefix', `config.prefix = ${JSON.stringify(cfg.prefix)}`);
} catch (e) {
  line('fail', 'prefix', 'talkless/config.js failed to load: ' + e.message);
}

try {
  const n = fs.readdirSync(path.join(ROOT, 'talkless', 'commands'))
    .map((c) => path.join(ROOT, 'talkless', 'commands', c))
    .filter((p) => fs.statSync(p).isDirectory())
    .reduce((acc, p) => acc + fs.readdirSync(p).filter((f) => f.endsWith('.js')).length, 0);
  line(n > 100 ? 'ok' : 'warn', 'commands', `${n} command files on disk`);
} catch (e) {
  line('fail', 'commands', 'cannot read talkless/commands: ' + e.message);
}

for (const f of [['talkless', 'database', 'botmode.json'], ['talkless', 'database', 'bot-settings.json']]) {
  const p = path.join(ROOT, ...f);
  try {
    line('ok', f[2], fs.existsSync(p) ? fs.readFileSync(p, 'utf8').replace(/\s+/g, ' ').slice(0, 80) : 'missing (defaults used)');
  } catch (e) {
    line('warn', f[2], e.message);
  }
}

const numbersDir = path.join(ROOT, 'talkless', 'database', 'numbers');
if (fs.existsSync(numbersDir)) {
  for (const num of fs.readdirSync(numbersDir)) {
    const bm = path.join(numbersDir, num, 'botmode.json');
    if (fs.existsSync(bm)) {
      const mode = (JSON.parse(fs.readFileSync(bm, 'utf8')).mode) || 'public';
      line(mode === 'public' ? 'ok' : 'warn', 'mode', `${num} -> ${mode}${mode === 'private' ? ' (only owner/sudo get replies!)' : ''}`);
    }
  }
} else {
  line('ok', 'mode', 'no per-number data yet (defaults to public)');
}

const sessDir = path.join(ROOT, 'sessions');
const sessions = fs.existsSync(sessDir)
  ? fs.readdirSync(sessDir).filter((d) => fs.existsSync(path.join(sessDir, d, 'creds.json')))
  : [];
line(sessions.length ? 'ok' : 'warn', 'sessions', sessions.length ? sessions.join(', ') : 'no paired WhatsApp session on disk');

const pairsFile = path.join(ROOT, 'database', 'pairs.json');
if (!fs.existsSync(pairsFile)) {
  line('warn', 'pairs', 'database/pairs.json missing — /pair again if the bot does not reconnect');
}

// crash probe
console.log('\n--- loading the TALKLESS pack and dispatching ".ping" (up to 25s) ---\n');
const { spawnSync } = require('child_process');
const r = spawnSync(process.execPath, [__filename], {
  env: { ...process.env, XMD_SELFTEST_CHILD: '1' },
  encoding: 'utf8',
  timeout: 30000,
});
const out = (r.stdout || '') + (r.stderr || '');
process.stdout.write(out.split('\n').filter((l) => /COMMANDS|REPLIES|ALIVE|DISPATCH_THREW|TypeError|Error:|CHATBOT/.test(l)).join('\n') + '\n');

const replied = /REPLIES \[[^\]]+\]/.test(out) && !/REPLIES \[\]/.test(out);
const stayed = out.includes('ALIVE_AFTER_20S');

console.log('');
if (replied && stayed) line('ok', 'dispatch', 'pack replied to .ping and survived the load-time checks');
else if (replied && !stayed) line('fail', 'dispatch', 'replied, then the process DIED — see the TypeError above (global.log bug)');
else if (!replied && stayed) line('fail', 'dispatch', 'no reply and no crash: message was filtered (mode / prefix / session)');
else line('fail', 'dispatch', 'no reply and the process died during load');

const fails = results.filter((x) => x.state === 'fail').length;
console.log(`\n=== ${fails} failure(s). See REPORT.md for the fixes. ===\n`);
process.exit(fails ? 1 : 0);
