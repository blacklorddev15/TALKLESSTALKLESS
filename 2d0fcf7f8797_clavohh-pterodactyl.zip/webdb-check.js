// ============================================================
//   webdb-check.js  –  diagnose the website <-> Neon connection
//
//   node webdb-check.js      (or: npm run check:webdb)
//
//   Checks env, the pg driver, reachability, every table the website
//   uses, what is queued right now, and the local session folders.
//   Safe to run while the bot is running.
// ============================================================
'use strict';

try { require('dns').setDefaultResultOrder('ipv4first'); } catch {}

const fs = require('fs');
const path = require('path');

const ok   = (m) => console.log('  OK    ' + m);
const bad  = (m) => console.log('  FAIL  ' + m);
const info = (m) => console.log('  ..    ' + m);

async function main() {
  let failed = 0;

  console.log('\n1) environment');
  const url = String(process.env.NEON_DATABASE_URL || '').trim();
  if (!url) { bad('NEON_DATABASE_URL is not set (see .env.example)'); failed++; }
  else {
    ok('NEON_DATABASE_URL is set');
    try { info('host: ' + new URL(url).host); } catch { bad('NEON_DATABASE_URL is not a valid URL'); failed++; }
  }

  console.log('\n2) driver + modules');
  try { require.resolve('pg'); ok('pg'); }
  catch { bad('pg is missing — run "npm install pg"'); failed++; }

  let neon = null;
  try { neon = require('./helper/neon-db'); ok('helper/neon-db.js'); }
  catch (e) { bad('helper/neon-db.js: ' + e.message); failed++; }
  try { require('./helper/web-pairing'); ok('helper/web-pairing.js'); }
  catch (e) { bad('helper/web-pairing.js: ' + e.message); failed++; }

  console.log('\n3) local sessions');
  const dir = path.resolve(__dirname, 'sessions');
  if (!fs.existsSync(dir)) info('no sessions folder yet: ' + dir);
  else {
    const list = fs.readdirSync(dir, { withFileTypes: true })
      .filter((d) => d.isDirectory() && d.name !== '.backup')
      .map((d) => d.name);
    list.length
      ? list.forEach((sid) => info(`${sid}  creds.json ${fs.existsSync(path.join(dir, sid, 'creds.json')) ? 'present' : 'missing'}`))
      : info('no linked sessions');
  }

  if (url && neon) {
    console.log('\n4) database');
    const { query, TABLES } = neon;
    try { await query('SELECT 1'); ok('connection + TLS'); }
    catch (e) { bad('cannot reach the database: ' + e.message); failed++; }

    if (failed === 0) {
      try { await neon.ensureSchema(); ok('schema present (created what was missing)'); }
      catch (e) { bad('schema: ' + e.message); failed++; }

      for (const [name, table] of Object.entries(TABLES)) {
        try {
          const { rows } = await query(`SELECT count(*)::int AS n FROM ${table}`);
          ok(`${table} (${rows[0].n} row${rows[0].n === 1 ? '' : 's'})  [${name}]`);
        } catch (e) { bad(`${table}: ${e.message}`); failed++; }
      }

      try {
        const { rows } = await query(
          `SELECT id, phone, status FROM ${TABLES.requests} ORDER BY id DESC LIMIT 5`);
        info(rows.length
          ? 'latest requests: ' + rows.map((r) => `#${r.id} ${r.phone} ${r.status}`).join(', ')
          : 'no pairing requests yet - open the website and request a code');
      } catch { /* already reported */ }

      try {
        const { rows } = await query(
          `SELECT status, count(*)::int AS n FROM ${TABLES.requests} GROUP BY status`);
        info('request totals: ' + (rows.map((r) => `${r.status}=${r.n}`).join(', ') || 'none'));
      } catch { /* already reported */ }

      await neon.getPool().end().catch(() => {});
    }
  }

  console.log('\n' + (failed ? `${failed} problem(s) found.` : 'Everything checks out.') + '\n');
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
