# Omegatech song and TikTok commands

- `.play <song>` searches for a song and sends audio. It tries the song-search result's YouTube link with the existing download providers, then falls back to the returned preview when available.
- `.songsearch <song, artist, or lyric phrase>` shows the match, source details, and a preview when one is returned.
- `.lyrics <song or lyric phrase>` shows the matching lyric excerpt and source link. The search API may return an excerpt rather than full lyrics.
- `.tiktok <TikTok URL>` resolves and sends the video using the Omegatech all-downloader endpoint.
- `.ig <Instagram URL>` downloads public posts/reels using the existing scraper with API fallbacks. Social download captions identify TALKLESS XMD.
- `.youtube <YouTube URL> [video|audio]` downloads audio or video. Video mode selects the highest returned quality at or below 64 MB when available.
- `.songstatus <taskId>` checks a previously generated song task and sends ready tracks.

## Session setup for generated-song status

The status API requires an authenticated session. Set `OMEGATECH_SESSION` as an environment variable in the bot host's secret/environment settings before using `.songstatus`. Do not paste the session token into source code, configuration files, or public repositories. Pass the task ID to the command, for example `.songstatus <taskId>`.

This package only contains the task-status integration because the supplied API example is a status request; it does not include a generation/start-task endpoint.

## Optional auto-join after WhatsApp pairing

Set `AUTO_JOIN_GROUP_LINK` in the bot host's environment to your WhatsApp group invite link. After a paired session connects, the bot will attempt to join that group; reconnects are safe, and already-a-member responses are logged without disrupting startup. The invite link is not stored in the source archive.

## Single-session channel auto-reaction

The channel monitor is fixed to `120363426406372312@newsletter` and polls for new posts every 30 seconds. It reacts once per post using a varied emoji and persists message IDs to avoid duplicate reactions after restarts. Select exactly one paired account by setting either `CHANNEL_REACT_SESSION_ID` to its full session ID (for example, `wa_<user>_<number>`) or `CHANNEL_REACT_WA_NUMBER` to its WhatsApp number in international digits. The monitor is inactive until one selector is configured. No alternate newsletter target is supported.
