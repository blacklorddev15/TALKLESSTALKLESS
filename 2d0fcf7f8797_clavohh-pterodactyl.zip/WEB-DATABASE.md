# Website pairing over Neon — what was added

The bot keeps its Telegram pairing (`/pair`, `/delpair`, `/listpaired`). What is
new is the **website channel**: a Vercel pairing site writes requests into Neon,
this process answers them, and both sides read the same rows. No webhook, no
public URL, no port to expose — the database is the transport.

## Files added / changed

| File | Status | Role |
| --- | --- | --- |
| `helper/neon-db.js` | new | one pg pool, IPv4-first DNS, TLS, `ensureSchema()`, `ping()`, `status()` |
| `helper/web-pairing.js` | new | the three queues + socket lifecycle hooks |
| `schema-neon-website.sql` | new | same tables the site already uses |
| `webdb-check.js` | new | `npm run check:webdb` diagnostics |
| `index.js` | patched (4 places) | require, boot start, `onSocketOpen`, `onSocketClose`, `/webstatus` |
| `package.json` | patched | `pg` dependency + `check:webdb` script |
| `.env.example` | patched | `NEON_DATABASE_URL`, `WEBSITE_URL` |

Nothing else in the bot was touched: commands, the TALKLESS pack, Telegram
handlers and the Pterodactyl/VPS features are untouched.

## Setup

```bash
npm install                 # pulls pg along with everything else
# .env
NEON_DATABASE_URL=postgresql://...neon.tech/neondb?sslmode=require
WEBSITE_URL=https://your-pairing-site.vercel.app
npm run check:webdb          # env, driver, tables, queue contents
npm start
```

The tables are created on boot (`CREATE TABLE IF NOT EXISTS`). You can also run
`schema-neon-website.sql` in the Neon SQL editor — both paths end in the same
schema.

Leave `NEON_DATABASE_URL` empty and the bot behaves exactly as before: Telegram
pairing only, website bridge off, with one warning line at boot.

## Queue 1 — pairing requests

`talkless_pairing_requests` is the only table the website writes for pairing.

```
pending ──claim(3s)──► processing ──code──► code_generated ──socket opens──► connected
                                     └─ 90s without a code ──► failed
                                     └─ expires_at passed ──► expired
                                     └─ 401/403 from WhatsApp ──► failed
```

- The claimed row becomes session `wa_web_<phone>` in `sessions/`.
- The pairing code is constant (`TALKLESS`, uppercase, 8 chars) because
  `startWhatsApp` already requests that exact code; the callback writes it to
  `pairing_code` the moment WhatsApp returns it.
- If the number already has a live socket, the row is failed with
  *"This number is already connected."* instead of fighting over the session.
- If the number has a folder but no live socket, the folder is **archived** to
  `sessions/.backup/<sessionId>_<timestamp>` (last 3 kept) before re-pairing —
  never hard-deleted, so the old linked device keeps decrypting.

## Queue 2 — session strings pasted on the site

`talkless_session_submissions` carries `session` = `TALKLESS!<base64>`.

```
pending ──claim(5s)──► claimed ──creds written──► connecting ──socket opens──► connected
                                                 └─ parse/socket error ──► failed
```

Accepted inputs: `TALKLESS!<base64>`, bare base64, URL-safe base64, fenced
base64, raw `creds.json` JSON (with or without a `{ creds: … }` wrapper).
Anything without `creds.me.id` is rejected with a clear reason instead of
writing a broken folder.

## Queue 3 — the website's `/session` page

`talkless_session_imports` — same idea, separate table, 8s poll with
`FOR UPDATE SKIP LOCKED` so several bot instances never grab the same row.

```
pending ──claim(8s)──► claimed ──payload wiped──► connected | failed | expired
                                                 └─ 45s without a socket ──► failed
```

The credential column is set to `NULL` as soon as the creds file is written, so
the database never keeps a usable secret longer than the import needs it.

## Session mirror

`talkless_sessions (id, phone, status, updated_at)` is upserted on every socket
event: `connected` on open, `disconnected` on close. The website's counters are
therefore real, not assumed.

## Where it hooks into the bot

- `index.js` → `webPairing.startAll({ startWhatsApp: global._startWhatsApp })`
  next to `startSessionWatcher()`.
- `connection === 'open'` → `webPairing.onSocketOpen(waNum)` closes the pairing
  row, marks the paste/import row connected, and mirrors the session.
- `connection === 'close'` → `webPairing.onSocketClose(sessionId, code)` mirrors
  the disconnect and fails pending rows on `401`/`403` only (a `515` restart is
  part of a normal pairing and must not be reported as a failure).

## Files and data created

```
sessions/wa_web_<phone>/creds.json          website-paired account
sessions/.backup/wa_web_<phone>_<ts>/       archived predecessor, last 3 kept
```

The existing `sessions/wa_<telegramId>_<phone>/` folders are untouched, and a
number paired through Telegram is never re-paired through the website — it is
reported as already connected.

## Checking it

```bash
npm run check:webdb      # driver, TLS, schema, row counts, latest requests
```

In Telegram, owners also get `/webstatus`:

```
🌐 Website pairing (Neon)
State: ONLINE
Host: ep-xxx.region.aws.neon.tech
Requests waiting: 0
Imports waiting: 0
Loops: pairing=on paste=on import=on
Tables: talkless_pairing_requests, talkless_sessions, ...
```

## Deployment notes

- Run this on an always-on host (VPS/panel/Docker). Serverless cannot hold the
  sockets or the polling loops.
- One instance per process is fine, several instances are also fine for the
  claim queries (`SKIP LOCKED`); what is never fine is two processes holding the
  same session folder.
- The website needs the same `NEON_DATABASE_URL`; nothing else is shared.
- `sessions/` and `.env` are credentials — keep them out of git.
