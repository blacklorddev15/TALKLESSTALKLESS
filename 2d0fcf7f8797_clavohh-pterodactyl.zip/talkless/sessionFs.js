'use strict';
/**
 * Makes Talkless's on-disk stores per-number.
 *
 * Installs a thin remap on `fs` (and `fs.promises`) so any path inside
 *   talkless/database/...  or  talkless/data/...
 * is transparently redirected to
 *   talkless/database/numbers/<sessionId>/...   (or talkless/data/numbers/<sessionId>/...)
 * when a session context is active. The original file is used as the seed
 * template the first time a number touches it.
 *
 * Nothing outside those two trees is affected, so the host bot's own files
 * (sessions/, database/settings.json, case.js data) are untouched.
 */
const path = require('path');
const fs = require('fs');
const { current } = require('./utils/sessionCtx');

const ROOTS = [
  path.join(__dirname, 'database') + path.sep,
  path.join(__dirname, 'data') + path.sep,
];
const NS = 'numbers' + path.sep;

const orig = {
  existsSync: fs.existsSync.bind(fs),
  mkdirSync: fs.mkdirSync.bind(fs),
  copyFileSync: fs.copyFileSync.bind(fs),
};

function scoped(p) {
  const sid = current();
  if (!sid || typeof p !== 'string') return p;

  const abs = path.isAbsolute(p) ? p : path.resolve(p);
  for (const root of ROOTS) {
    if (!abs.startsWith(root)) continue;
    const rel = abs.slice(root.length);
    if (rel.startsWith(NS)) return p;                 // already per-number
    if (!rel.includes('.') && !abs.endsWith('.json')) return p;  // skip dirs like .../temp

    const target = path.join(root, 'numbers', sid, rel);
    try {
      if (!orig.existsSync(target)) {
        orig.mkdirSync(path.dirname(target), { recursive: true });
        if (orig.existsSync(abs)) orig.copyFileSync(abs, target);
      }
    } catch (_) { /* seeding is best-effort */ }
    return target;
  }
  return p;
}

const SYNC = [
  'readFileSync', 'writeFileSync', 'appendFileSync', 'existsSync', 'mkdirSync',
  'unlinkSync', 'rmSync', 'rmdirSync', 'statSync', 'lstatSync', 'readdirSync',
  'copyFileSync', 'renameSync', 'openSync', 'truncateSync', 'chmodSync',
  'createReadStream', 'createWriteStream', 'accessSync', 'readlinkSync',
];
// two-path calls need BOTH arguments remapped
const TWO_PATH = ['renameSync', 'copyFileSync', 'linkSync', 'symlinkSync'];

for (const k of SYNC) {
  if (typeof fs[k] !== 'function') continue;
  const fn = fs[k].bind(fs);
  if (TWO_PATH.includes(k)) {
    fs[k] = function (a, b, ...rest) { return fn(scoped(a), scoped(b), ...rest); };
  } else {
    fs[k] = function (p, ...rest) { return fn(scoped(p), ...rest); };
  }
}

if (fs.promises) {
  for (const k of ['readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rm',
                   'stat', 'lstat', 'readdir', 'copyFile', 'rename', 'open',
                   'access', 'truncate', 'chmod']) {
    if (typeof fs.promises[k] !== 'function') continue;
    const fn = fs.promises[k].bind(fs.promises);
    if (TWO_PATH.includes(k)) {
      fs.promises[k] = function (a, b, ...rest) { return fn(scoped(a), scoped(b), ...rest); };
    } else {
      fs.promises[k] = function (p, ...rest) { return fn(scoped(p), ...rest); };
    }
  }
}

function sessionFromSock(sock) {
  const id = (sock && sock.user && sock.user.id) || '';
  const num = String(id).split('@')[0].split(':')[0].replace(/\D/g, '');
  return num || null;
}

module.exports = { scoped, sessionFromSock, runWithSession: require('./utils/sessionCtx').run };
