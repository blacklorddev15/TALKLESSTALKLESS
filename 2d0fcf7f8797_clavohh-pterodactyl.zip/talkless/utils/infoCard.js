/**
 * Info cards (.botinfo / .botstatus): one box, picture on top, buttons at the bottom.
 *
 *  ╔═════════════════╗
 *  ║  🤖 𝗕𝗢𝗧 𝗜𝗡𝗙𝗢
 *  ╠═════════════════╣
 *  ║ ᴍᴀɪɴ
 *  ║╠ Name ➜ TALKLESS XMD
 */
const fs = require('fs');
const path = require('path');
const config = require('../config');
const { boldFont, smallCaps, MAXW } = require('./menuLayout');
const { sendButtons } = require('gifted-btns');

const TOP = '╔══════════════════════════╗';
const MID = '╠══════════════════════════╣';
const BOT = '╚══════════════════════════╝';
const cut = (v, n) => { v = String(v ?? ''); return v.length > n ? v.slice(0, n - 1) + '…' : v; };

/** sections: [{ label:'main', rows:[['Name','TALKLESS XMD'], ...] }] */
function card(icon, title, sections, footerNote = '') {
  const lines = [TOP, `║  ${icon} ${boldFont(title)}`, MID];
  sections.forEach((sec, i) => {
    if (i) lines.push('║');
    lines.push(`║ ${smallCaps(sec.label)}`);
    for (const [k, v] of sec.rows) lines.push(`║╠ ${k} ➜ ${cut(v, Math.max(6, MAXW - k.length - 6))}`);
  });
  if (footerNote) lines.push(MID, `║ ${footerNote}`);
  lines.push(BOT);
  return lines.join('\n');
}

let remote = null;
async function menuImage() {
  const custom = path.join(__dirname, '../data/custom_menu.jpg');
  try { if (fs.existsSync(custom)) return fs.readFileSync(custom); } catch {}
  if (remote) return remote;
  if (config.menuImageUrl) {
    try {
      const r = await require('axios').get(config.menuImageUrl, { responseType: 'arraybuffer', timeout: 8000 });
      return (remote = Buffer.from(r.data));
    } catch (e) { console.warn('[infoCard] image download failed:', e.message); }
  }
  for (const f of ['menu1.jpg', 'bot_image.jpg', 'menu2.jpg']) {
    try { return fs.readFileSync(path.join(__dirname, f)); } catch {}
  }
  return null;
}

/** One message: image + card text + buttons (falls back to text + buttons, then plain text). */
async function sendCard(sock, chatId, msg, text, buttons) {
  const footer = `Powered by ${config.poweredBy || config.botName}`;
  const img = await menuImage();
  try {
    return await sendButtons(sock, chatId, {
      image: img ? { buffer: img, mimetype: 'image/jpeg' } : undefined,
      text, footer, buttons
    }, { quoted: msg });
  } catch (e) {
    console.warn('[infoCard] image buttons failed:', e.message);
    try { return await sendButtons(sock, chatId, { title: '', text, footer, buttons }, { quoted: msg }); }
    catch { return sock.sendMessage(chatId, { text }, { quoted: msg }); }
  }
}

module.exports = { card, sendCard };
