/** WhatsApp menu renderer styled to match the latest TALKLESS XMD sample. */
const TOP = '╔══════════════════╗';
const MID = '╠══════════════════╣';
const BOT = '╚══════════════════╝';
const BOLD_U = 0x1D5D4, BOLD_L = 0x1D5EE, BOLD_D = 0x1D7EC;
const boldFont = str => [...String(str)].map(ch => {
  const c = ch.codePointAt(0);
  if (c >= 65 && c <= 90) return String.fromCodePoint(BOLD_U + c - 65);
  if (c >= 97 && c <= 122) return String.fromCodePoint(BOLD_L + c - 97);
  if (c >= 48 && c <= 57) return String.fromCodePoint(BOLD_D + c - 48);
  return ch;
}).join('');
const MAXW = 27;
const fit = (t, n = MAXW - 3) => {
  const a = [...String(t)];
  return a.length > n ? a.slice(0, n - 1).join('') + '…' : String(t);
};
const list = s => s.split(/\s+/).filter(Boolean);
const set = s => { const a = list(s); return n => a.includes(n); };
const LAYOUT = {
  general: { icon: '🏠', title: 'MAIN MENU', groups: [
    ['ℹ️', 'BOT INFO', set('menu alive ping uptime botinfo botstatus owner list getsettings myactivity groupinfo groupstats antibug')],
    ['🖼️', 'STICKERS & PICS', set('sticker take attp circlesticker crop telegramsticker simage img image2 getpp delpp setprofile')],
    ['🛠️', 'HANDY TOOLS', set('translate tts transcribe google define time qr ssweb news2 write fancy apk pair reshare')]
  ] },
  ai: { icon: '🤖', title: 'AI COMMANDS', groups: [
    ['💬', 'CHAT AI', set('ai aiLlama bard blackbox chatgpt claude copilot deepseek deepseekv3 gemini gpt4o grok metaai mistral o3 perplexity qwen venice wormgpt searchai')],
    ['👅', 'IMAGE & VOICE', set('generate imageedit imagehd magicstudio removebg vision aitts whisper')],
    ['✍️', 'WRITING & CODE', set('codedescribe codegen lyricsgen speechwriter summarize scite dreamanalyzer')]
  ] },
  media: { icon: '🎵', title: 'MEDIA', groups: [
    ['🎶', 'MUSIC', set('play play2 play3 songsearch songstatus spotify spotify2 soundcloud lyrics')],
    ['🎬', 'VIDEO', set('video2 video3 youtube ytvideo ytsearch ptv trim')],
    ['📥', 'DOWNLOADERS', set('facebook instagram igs igsc tiktok tiktok2 twitter pinterest')]
  ] },
  sports: { icon: '⚽', title: 'SPORTS', groups: [
    ['🔴', 'LIVE SCORES', set('livescore livehighlights')],
    ['🏆', 'LEAGUES', set('epl bundesliga laliga ligue1 seriea ucl euros')],
    ['🌍', 'FIFA WORLD CUP', n => /^fifa/.test(n)],
    ['🔍', 'SEARCH & NEWS', set('playersearch kteamsearch venuesearch gameevents footballnews bet')]
  ] },
  textmaker: { icon: '🎨', title: 'LOGO MAKER', hint: ['✦ USE: fire Name', '✦ TWO TEXTS: blackpink A|B'], groups: [] },
  fun: { icon: '🎮', title: 'FUN & GAMES', groups: [
    ['🎲', 'GAMES', set('tictactoe bomb wyr truth dare question')],
    ['😂', 'JOKES & TEXT', set('joke fact quotes meme memesearch pickupline compliment flirt insult')],
    ['🎯', 'RATES & MORE', set('gayrate ship paranoia wasted pies')]
  ] },
  reaction: { icon: '😍', title: 'REACTIONS', groups: [] },
  anime: { icon: '🌸', title: 'ANIME', groups: [] },
  tools: { icon: '🧰', title: 'TOOLS', groups: [
    ['🎧', 'AUDIO EFFECTS', set('bass blown chipmunk deep earrape echo fast nightcore reverse robot slow treble volaudio vocalremove karaoke instrumental toptt')],
    ['🔗', 'FILES & LINKS', set('catbox uguu imgbb shorturl mediafire fetch encrypt')],
    ['📸', 'SCREENSHOT & OCR', set('ssdsktp ssrecord ocr enhance getdevice')]
  ] },
  convert: { icon: '🔄', title: 'CONVERTERS', groups: [] },
  utility: { icon: '🧮', title: 'UTILITIES', hint: ['COUNTRY INFO', '✦ kenya'], groups: [] },
  admin: { icon: '👮', title: 'GROUP ADMIN', groups: [
    ['👥', 'MEMBERS', set('add kick promote demote demoteall approve reject join warn resetwarn mute unmute staff')],
    ['📢', 'TAGGING', set('tagall all hidetag vcf listonline listoffline disp')],
    ['🛡️', 'PROTECTION', n => /^anti/.test(n)],
    ['👋', 'WELCOME', set('welcome goodbye setwelcome setgoodbye')],
    ['⚙️', 'GROUP SETTINGS', set('grouplink getgroupdesc getgroupprofile setgroupprofile setsticker autosticker clean chatbot')]
  ] },
  owner: { icon: '👑', title: 'OWNER ONLY', groups: [
    ['⚙️', 'BOT SETTINGS', set('mode restart setprefix setbotname setbotpp setfont setmenu setmenuimage setownername setownernumber settimezone setnewsletter getsession leave')],
    ['🤖', 'AUTOMATION', n => /^auto/.test(n) || ['alwaysonline', 'readreceipts'].includes(n)],
    ['🛡️', 'PROTECTION', set('antibug anticall antidelete antideletestatus antiedit')],
    ['👤', 'USERS & SUDO', set('addsudo removesudo sudolist block unblock')],
    ['📣', 'BROADCAST', set('broadcast forward creategc mygroups invite newsletter groupstatus tostatus savestatus viewonce delete cat')]
  ] },
  movies: { icon: '📂', title: 'MOVIES', groups: [
    ['🔍', 'SEARCH', n => /search$/.test(n)],
    ['ℹ️', 'DETAILS', n => /detail$/.test(n) || n === 'actor' || n === 'trailer'],
    ['📥', 'WATCH / DOWNLOAD', set('moviedl moviebox dramabox iboxanime iboxmovies iboxtv')]
  ] },
  religion: { icon: '📂', title: 'RELIGION', groups: [] }
};
const ORDER = ['general', 'ai', 'media', 'sports', 'textmaker', 'fun', 'reaction', 'anime', 'tools', 'convert', 'utility', 'admin', 'owner', 'religion', 'movies'];
const hidden = n => !n || /^cta_/.test(n) || n.includes(' ') || /^[A-Z]/.test(n) || n.includes('/');
function rows(names) {
  const out = [];
  for (const n of names) {
    const item = `✦ ${n}`;
    if ([...item].length <= MAXW - 2) out.push(`║ ${item}`);
    else {
      for (let i = 0; i < [...item].length; i += MAXW - 4) {
        const chunk = [...item].slice(i, i + MAXW - 4).join('');
        out.push(`║ ${i ? '  ' : ''}${chunk}`);
      }
    }
  }
  return out;
}
function section(key, cmds, prefix) {
  const conf = LAYOUT[key] || { icon: '📂', title: key.toUpperCase(), groups: [] };
  const names = [...new Set(cmds.map(c => c.name))].filter(n => !hidden(n)).sort((a, b) => a.localeCompare(b));
  if (!names.length) return '';
  const lines = [`║ ${boldFont(conf.title)} (${names.length})`, MID];
  const left = new Set(names);
  let groupsShown = 0;
  for (const [icon, label, pred] of conf.groups) {
    const matches = names.filter(n => left.has(n) && pred(n));
    if (!matches.length) continue;
    matches.forEach(n => left.delete(n));
    if (groupsShown) lines.push('║');
    lines.push(`║ ${boldFont(label)}`, ...rows(matches));
    groupsShown++;
  }
  const rest = names.filter(n => left.has(n));
  if (rest.length) {
    if (groupsShown) lines.push('║');
    if (conf.groups.length) lines.push(`║ ${boldFont('MORE')}`);
    lines.push(...rows(rest));
  }
  if (conf.hint?.length) {
    if (names.length) lines.push('║');
    for (const hint of conf.hint) lines.push(`║ ${hint.startsWith('✦') ? hint : boldFont(hint)}`);
  }
  return lines.join('\n');
}
function buildMenuParts({ bot, prefix, header, categories, readmore = '' }) {
  const top = [
    TOP,
    `║ ✦ ${boldFont(String(bot).toUpperCase())} ✦`,
    MID,
    `║ ${boldFont('BOT INFO')}`,
    MID,
    ...header.map(h => `║ ✦ ${fit(h)}`),
    MID,
    `║ ${boldFont('HOW TO USE')}`,
    MID,
    '║ ✦ Type: command',
    '║ ✦ Example: play song'
  ].join('\n');
  const keys = Object.keys(categories).filter(k => categories[k]?.length);
  const ordered = [...ORDER.filter(k => keys.includes(k)), ...keys.filter(k => !ORDER.includes(k)).sort()];
  const sections = ordered.map(k => section(k, categories[k], prefix)).filter(Boolean);
  const full = top + (readmore ? `\n${readmore}` : '') + `\n${MID}\n` + sections.join(`\n${MID}\n`) + `\n${BOT}`;
  return { full, head: top + `\n${BOT}`, sections };
}
function buildMenu(opts) { return buildMenuParts(opts).full; }
module.exports = { buildMenu, buildMenuParts, boldFont, MAXW };
