'use strict';

const database = require('../database');

function unwrap(message) {
  let current = message;
  for (let i = 0; i < 5 && current; i++) {
    if (current.ephemeralMessage?.message) current = current.ephemeralMessage.message;
    else if (current.viewOnceMessage?.message) current = current.viewOnceMessage.message;
    else if (current.viewOnceMessageV2?.message) current = current.viewOnceMessageV2.message;
    else if (current.viewOnceMessageV2Extension?.message) current = current.viewOnceMessageV2Extension.message;
    else break;
  }
  return current;
}

function stickerFromMessage(msg) {
  const message = unwrap(msg?.message || {});
  if (message.stickerMessage) return message.stickerMessage;
  const context = message.extendedTextMessage?.contextInfo || message.imageMessage?.contextInfo || message.videoMessage?.contextInfo;
  return unwrap(context?.quotedMessage || {})?.stickerMessage || null;
}

function hashSticker(sticker) {
  const value = sticker?.fileSha256;
  if (!value) return '';
  if (Buffer.isBuffer(value) || value instanceof Uint8Array || Array.isArray(value)) {
    return Buffer.from(value).toString('base64');
  }
  return String(value).trim();
}

function getMap() {
  try {
    const value = database.getBotSetting('stickerCommandAliases');
    return value && typeof value === 'object' && !Array.isArray(value) ? { ...value } : {};
  } catch (_) {
    return {};
  }
}

function saveMap(map) {
  return database.setBotSetting('stickerCommandAliases', map);
}

module.exports = { unwrap, stickerFromMessage, hashSticker, getMap, saveMap };
