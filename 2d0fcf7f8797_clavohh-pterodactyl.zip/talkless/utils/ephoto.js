/**
 * Robust ephoto360 text-effect generator.
 *
 * Why the old code failed ("An error occurred while generating the effect"):
 *  - it posted a Node FormData with a hand-written 'Content-Type: multipart/form-data'
 *    header (no boundary) -> ephoto360 rejected the form;
 *  - effects that need several texts / a radio choice were sent incomplete;
 *  - one failed scrape = one failed command (no retry, no fallback).
 *
 * make(url, text) -> { image }   (tries the scraper twice, then the `mumaker` package)
 */
const axios = require('axios');
const FormData = require('form-data');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const decode = s => String(s || '').replace(/&quot;/g, '"').replace(/&#039;|&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

// Read every <input ...> tag as { name, value, type }
function inputs(html) {
  const out = [];
  for (const m of html.matchAll(/<input\b[^>]*>/gi)) {
    const tag = m[0];
    const attr = n => { const a = tag.match(new RegExp(`\\b${n}\\s*=\\s*("([^"]*)"|'([^']*)')`, 'i')); return a ? decode(a[2] ?? a[3]) : undefined; };
    out.push({ name: attr('name'), value: attr('value'), type: attr('type') });
  }
  return out;
}
const cookieOf = res => (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');

async function scrape(url, text) {
  const page = await axios.get(url, { headers: { 'user-agent': UA }, timeout: 20000 });
  const ins = inputs(String(page.data));
  const val = n => ins.find(i => i.name === n)?.value;
  const token = val('token'), build_server = val('build_server'), build_server_id = val('build_server_id');
  if (!token || !build_server) throw new Error('effect page layout not recognised');

  // Some effects need 2+ texts: allow "a|b" and repeat the last value for the rest.
  const slots = ins.filter(i => i.name === 'text[]').length || 1;
  const parts = text.split('|').map(s => s.trim()).filter(Boolean);
  const form = new FormData();
  for (let i = 0; i < slots; i++) form.append('text[]', parts[i] ?? parts[parts.length - 1] ?? text);
  // Effects with a style picker: choose the first option.
  const seenRadio = new Set();
  for (const i of ins) if (i.type === 'radio' && i.name && !seenRadio.has(i.name)) { seenRadio.add(i.name); form.append(i.name, i.value); }
  form.append('submit', 'GO');
  form.append('token', token);
  form.append('build_server', build_server);
  form.append('build_server_id', build_server_id);

  const cookie = cookieOf(page);
  const res = await axios.post(url, form, {
    headers: { ...form.getHeaders(), 'user-agent': UA, accept: '*/*', cookie, referer: url },
    timeout: 25000,
    maxRedirects: 3
  });
  const raw = String(res.data).match(/name=["']form_value_input["'][^>]*value=["']([^"']*)["']/i) ||
              String(res.data).match(/value=["']([^"']*)["'][^>]*name=["']form_value_input["']/i);
  if (!raw) throw new Error('effect form rejected');
  const json = JSON.parse(decode(raw[1]));
  json['text[]'] = json.text;
  delete json.text;

  const { data } = await axios.post('https://en.ephoto360.com/effect/create-image', new URLSearchParams(json), {
    headers: { 'user-agent': UA, cookie, referer: url },
    timeout: 30000
  });
  if (!data?.success && !data?.image) throw new Error(data?.error || 'image not created');
  return { image: build_server + data.image };
}

async function make(url, text) {
  let lastErr;
  for (let i = 0; i < 2; i++) {            // 2 quick attempts
    try { return await scrape(url, text); } catch (e) { lastErr = e; await new Promise(r => setTimeout(r, 700)); }
  }
  try {                                    // last resort: the mumaker package
    const r = await require('mumaker').ephoto(url, text);
    if (r?.image) return { image: r.image };
  } catch (e) { lastErr = lastErr || e; }
  throw lastErr;
}

module.exports = { make, ephoto: make };
