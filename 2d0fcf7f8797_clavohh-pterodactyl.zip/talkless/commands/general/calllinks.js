async function sendCallLink(sock, msg, extra, mediaType) {
  const label = mediaType === 'audio' ? 'Voice' : 'Video';
  try {
    if (typeof sock.createCallLink !== 'function') {
      throw new Error('Your installed Baileys version does not support WhatsApp call-link creation. Update @whiskeysockets/baileys and restart the bot.');
    }
    const token = await sock.createCallLink(mediaType);
    if (!token || typeof token !== 'string') throw new Error('WhatsApp did not return a call-link token. Please try again.');
    const link = /^https?:\/\//i.test(token)
      ? token
      : `https://call.whatsapp.com/${mediaType === 'audio' ? 'voice' : 'video'}/${token}`;
    await extra.reply(`☎️ *TALKLESS XMD ${label} Call Link*\n\n${link}\n\nOpen the link to join or share it with people you trust. This creates a WhatsApp call link; it does not start the call automatically. Unused links expire after 30 days.`);
  } catch (error) {
    console.error(`[${mediaType}call]`, error.message);
    await extra.reply(`❌ *TALKLESS XMD ${label} Call Link*\n\n${error.message || 'Could not create a call link. Please try again.'}`);
  }
}

module.exports = [
  {
    name: 'voicecall',
    aliases: ['callvoice', 'voicecalllink'],
    category: 'general',
    description: 'Create a shareable WhatsApp voice-call link',
    usage: '.voicecall',
    async execute(sock, msg, args, extra) {
      return sendCallLink(sock, msg, extra, 'audio');
    }
  },
  {
    name: 'videocall',
    aliases: ['callvideo', 'videocalllink'],
    category: 'general',
    description: 'Create a shareable WhatsApp video-call link',
    usage: '.videocall',
    async execute(sock, msg, args, extra) {
      return sendCallLink(sock, msg, extra, 'video');
    }
  }
];
