const config = require('../../config');
const CHANNEL_JID = config.newsletterJid;
module.exports = {
  name: 'setnewsletter',
  aliases: ['setnl', 'setchannel'],
  category: 'owner',
  description: 'Show the fixed newsletter ID (cannot be changed)',
  usage: '.setnewsletter',
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(sock, msg, args, extra) {
    const requested = (args || []).join(' ').trim();
    if (requested && requested !== CHANNEL_JID) {
      return extra.reply(`❌ This bot is locked to one newsletter:\n${CHANNEL_JID}`);
    }
    return extra.reply(`📰 *Fixed Newsletter*\n\n🆔 ${CHANNEL_JID}\n\nThis channel ID cannot be changed with this command.`);
  }
};
