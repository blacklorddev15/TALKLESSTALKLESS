/**
 * AntiDelete — recovers deleted messages (text, image, video, audio, sticker).
 *
 * Modes:
 *   chat    → GLOBAL: reveals deleted msg in the same chat it was deleted from (all chats)
 *   private → GLOBAL: ALL deleted msgs across ALL chats go to owner's DM
 *   off     → disabled globally
 */

const fs = require('fs');
const path = require('path');
const config = require(require('path').join(global.__ROOT__, 'config'));
const {
  downloadContentFromMessage
} = require('@whiskeysockets/baileys');
const CONFIG_PATH = path.join(__dirname, '../../data/antidelete.json');
// Per-session message stores (every paired number keeps its own cache)
const sessionStores = new Map();   // sessionKey -> { chats: Map<chatId, Map<msgId, entry>>, mediaBytes, mediaQueue }
const handledDeletes = new Set();  // dedupe between messages.update and protocolMessage paths
const MAX_PER_CHAT = 500;
const MAX_MEDIA_BYTES = 25 * 1024 * 1024;   // buffered media cap per session
const MAX_SINGLE_MEDIA = 8 * 1024 * 1024;   // don't buffer files bigger than this
function sessionKey(sock) {
  const id = sock?.user?.id || sock?.__waNum || 'default';
  return String(id).split('@')[0].split(':')[0] || 'default';
}
function getStore(sock) {
  const k = sessionKey(sock);
  let st = sessionStores.get(k);
  if (!st) {
    st = { chats: new Map(), mediaBytes: 0, mediaQueue: [] };
    sessionStores.set(k, st);
  }
  return st;
}
const loadConfig = () => {
  try {
    if (!fs.existsSync(CONFIG_PATH)) fs.writeFileSync(CONFIG_PATH, '{}');
    return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  } catch {
    return {};
  }
};
const saveConfig = cfg => {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
  } catch {}
};
const MEDIA_MAP = {
  imageMessage: 'image',
  videoMessage: 'video',
  audioMessage: 'audio',
  stickerMessage: 'sticker',
  documentMessage: 'document'
};
function unwrap(raw) {
  return raw.ephemeralMessage?.message || raw.viewOnceMessageV2Extension?.message || raw.viewOnceMessageV2?.message || raw.viewOnceMessage?.message || raw;
}
const storeMessage = (msg, sock) => {
  try {
    if (!msg?.key?.id || !msg.message) return;
    const chatId = msg.key.remoteJid;
    if (!chatId || chatId === 'status@broadcast') return;
    const sender = msg.key.participant || (msg.key.fromMe ? (sock?.user?.id || chatId) : chatId);
    const inner = unwrap(msg.message);
    let text = inner.conversation || inner.extendedTextMessage?.text || inner.imageMessage?.caption || inner.videoMessage?.caption || inner.documentMessage?.caption || null;
    const mtype = Object.keys(MEDIA_MAP).find(k => inner[k]);
    let type = mtype ? MEDIA_MAP[mtype] : 'text';
    // other message kinds: keep a readable description so nothing is lost
    if (!text && !mtype) {
      if (inner.contactMessage) text = `👤 Contact: ${inner.contactMessage.displayName || ''}`;
      else if (inner.contactsArrayMessage) text = `👥 Contacts: ${(inner.contactsArrayMessage.contacts || []).map(c => c.displayName).join(', ')}`;
      else if (inner.locationMessage || inner.liveLocationMessage) {
        const l = inner.locationMessage || inner.liveLocationMessage;
        text = `📍 Location: https://maps.google.com/?q=${l.degreesLatitude},${l.degreesLongitude}`;
      } else if (inner.pollCreationMessage || inner.pollCreationMessageV3) {
        const pl = inner.pollCreationMessage || inner.pollCreationMessageV3;
        text = `📊 Poll: ${pl.name || ''}`;
      } else return;
    }
    const entry = {
      sender,
      fromMe: !!msg.key.fromMe,
      pushName: msg.pushName || null,
      timestamp: msg.messageTimestamp,
      type,
      mtype: mtype || null,
      inner,
      text: text || null,
      buffer: null
    };
    const st = getStore(sock);
    if (!st.chats.has(chatId)) st.chats.set(chatId, new Map());
    const chatMap = st.chats.get(chatId);
    chatMap.set(msg.key.id, entry);
    if (chatMap.size > MAX_PER_CHAT) chatMap.delete(chatMap.keys().next().value);

    // Grab the media NOW: once the sender deletes it the CDN copy can vanish.
    if (mtype) {
      const size = Number(inner[mtype]?.fileLength || 0);
      if (!size || size <= MAX_SINGLE_MEDIA) {
        downloadMedia(entry).then(buf => {
          if (!buf || !buf.length || buf.length > MAX_SINGLE_MEDIA) return;
          entry.buffer = buf;
          st.mediaBytes += buf.length;
          st.mediaQueue.push(entry);
          while (st.mediaBytes > MAX_MEDIA_BYTES && st.mediaQueue.length) {
            const old = st.mediaQueue.shift();
            if (old.buffer) { st.mediaBytes -= old.buffer.length; old.buffer = null; }
          }
        }).catch(() => {});
      }
    }
  } catch (_) {}
};
async function downloadMedia(stored) {
  try {
    const {
      inner,
      mtype
    } = stored;
    const stream = await downloadContentFromMessage(inner[mtype], MEDIA_MAP[mtype]);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
  } catch {
    return null;
  }
}

// Fetch group name if it's a group chat
async function getChatLabel(sock, chatId) {
  try {
    if (chatId.endsWith('@g.us')) {
      const meta = await sock.groupMetadata(chatId);
      return `👥 *${meta.subject}*`;
    }
    return `💬 DM (${chatId.split('@')[0]})`;
  } catch {
    return chatId.endsWith('@g.us') ? `👥 Group (${chatId.split('@')[0]})` : `💬 DM (${chatId.split('@')[0]})`;
  }
}
async function sendRecovered(sock, targetJid, stored, originChat, bufferOverride) {
  const { box } = require('../../utils/box');
  const senderNum = stored.sender?.split('@')[0]?.split(':')[0] || 'Unknown';
  const typeEmoji = { image: '🖼️', video: '🎬', audio: '🎵', sticker: '🧩', document: '📄', text: '📝' }[stored.type] || '📝';
  let where = '';
  if (originChat) {
    if (originChat.endsWith('@g.us')) {
      let name = originChat.split('@')[0];
      try { name = (await sock.groupMetadata(originChat)).subject || name; } catch {}
      where = `👥 ${name.length > 20 ? name.slice(0, 19) + '…' : name}`;
    } else where = '💬 Private chat';
  }
  const rows = [`👤 @${senderNum}`, `🕐 ${clock(stored.timestamp)}`, `${typeEmoji} ${stored.type}`];
  if (where) rows.push(where);
  const meta = box('🗑️ DELETED MESSAGE', rows.join('\n'));
  const mentions = stored.sender ? [stored.sender] : [];
  const withText = stored.text ? `${meta}\n\n${stored.text}` : meta;

  if (stored.type === 'text') {
    await sock.sendMessage(targetJid, { text: withText, mentions });
    return;
  }
  const buffer = bufferOverride || stored.buffer || await downloadMedia(stored);
  if (!buffer) {
    await sock.sendMessage(targetJid, { text: `${withText}\n\n⚠️ _Media expired (CDN link gone)._`, mentions });
    return;
  }
  if (stored.type === 'image') {
    await sock.sendMessage(targetJid, { image: buffer, caption: withText, mentions });
  } else if (stored.type === 'video') {
    await sock.sendMessage(targetJid, { video: buffer, caption: withText, mentions, mimetype: stored.inner?.videoMessage?.mimetype || 'video/mp4' });
  } else if (stored.type === 'audio') {
    await sock.sendMessage(targetJid, { audio: buffer, ptt: stored.inner?.audioMessage?.ptt === true, mimetype: stored.inner?.audioMessage?.mimetype || 'audio/ogg; codecs=opus' });
    await sock.sendMessage(targetJid, { text: withText, mentions });
  } else if (stored.type === 'sticker') {
    await sock.sendMessage(targetJid, { sticker: buffer, mimetype: stored.inner?.stickerMessage?.mimetype || 'image/webp' });
    await sock.sendMessage(targetJid, { text: withText, mentions });
  } else if (stored.type === 'document') {
    await sock.sendMessage(targetJid, { document: buffer, mimetype: stored.inner?.documentMessage?.mimetype || 'application/octet-stream', fileName: stored.inner?.documentMessage?.fileName || 'file', caption: withText, mentions });
  }
}

// ── Persistent log of every recovered message (so .antidelete fetch can replay them) ──
const LOG_PATH = path.join(__dirname, '../../data/deleted-log.json');
const MAX_LOG = 100;
const MAX_LOG_MEDIA = 1.5 * 1024 * 1024;   // media bigger than this is not kept in the log
function loadLog() {
  try {
    if (!fs.existsSync(LOG_PATH)) fs.writeFileSync(LOG_PATH, '[]');
    const a = JSON.parse(fs.readFileSync(LOG_PATH, 'utf8'));
    return Array.isArray(a) ? a : [];
  } catch { return []; }
}
function saveLog(arr) {
  try { fs.writeFileSync(LOG_PATH, JSON.stringify(arr.slice(-MAX_LOG))); } catch {}
}
function appendLog(chatId, stored, buffer) {
  try {
    const arr = loadLog();
    arr.push({
      chatId,
      sender: stored.sender || null,
      pushName: stored.pushName || null,
      timestamp: Number(stored.timestamp) || Math.floor(Date.now() / 1000),
      deletedAt: Date.now(),
      type: stored.type,
      text: stored.text || null,
      mime: stored.mtype ? stored.inner?.[stored.mtype]?.mimetype || null : null,
      fileName: stored.inner?.documentMessage?.fileName || null,
      ptt: stored.inner?.audioMessage?.ptt === true,
      media: buffer && buffer.length <= MAX_LOG_MEDIA ? buffer.toString('base64') : null
    });
    saveLog(arr);
  } catch (_) {}
}
function clock(ts) {
  return new Date((Number(ts) || Date.now() / 1000) * 1000).toLocaleString('en-GB', {
    hour12: false, timeZone: config.timezone || 'Africa/Nairobi',
    day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit'
  });
}

function ownerJid(sock) {
  const id = sock.user?.id;
  if (!id) return null;
  return id.includes(':') ? id.split(':')[0] + '@s.whatsapp.net' : id;
}
// Default is PRIVATE: every deleted message is delivered to the paired
// number's own chat ("Message yourself") unless .antidelete off / chat is set.
function currentMode() {
  const cfg = loadConfig();
  return cfg['_global']?.mode || 'private';
}
const handleDelete = async (sock, revokeItems) => {
  try {
    const globalMode = currentMode();
    const botJid = ownerJid(sock);
    if (globalMode === 'off') return;
    const st = getStore(sock);
    for (const item of revokeItems) {
      const chatId = item.key?.remoteJid;
      const deletedId = item.key?.id;
      if (!chatId || !deletedId) continue;
      if (chatId === 'status@broadcast') continue;
      const dk = sessionKey(sock) + '|' + chatId + '|' + deletedId;
      if (handledDeletes.has(dk)) continue;
      handledDeletes.add(dk);
      if (handledDeletes.size > 5000) handledDeletes.delete(handledDeletes.values().next().value);
      let targetJid;
      if (globalMode === 'chat') targetJid = chatId;
      else targetJid = botJid;           // private
      if (!targetJid) continue;
      const stored = st.chats.get(chatId)?.get(deletedId);
      if (!stored) continue;             // sent before the bot was online: nothing to recover
      if (stored.fromMe) continue;       // you deleting your own message is not recovered
      try {
        const buf = stored.mtype ? (stored.buffer || await downloadMedia(stored)) : null;
        appendLog(chatId, stored, buf);          // keep it for .antidelete fetch
        await sendRecovered(sock, targetJid, stored, chatId, buf);
      } catch (e) {
        console.error('[ANTIDELETE] send failed:', e.message);
      }
    }
  } catch (e) {
    console.error('[ANTIDELETE] handleDelete error:', e.message);
  }
};
// Replay every logged deleted message into the paired (private) chat.
async function fetchAll(sock, count) {
  const target = ownerJid(sock);
  if (!target) return 0;
  const log = loadLog();
  const items = count ? log.slice(-count) : log;
  let sent = 0;
  for (const e of items) {
    const stored = {
      sender: e.sender, pushName: e.pushName, timestamp: e.timestamp, type: e.type, text: e.text,
      mtype: null,
      inner: {
        imageMessage: { mimetype: e.mime }, videoMessage: { mimetype: e.mime },
        audioMessage: { mimetype: e.mime, ptt: e.ptt }, stickerMessage: { mimetype: e.mime },
        documentMessage: { mimetype: e.mime, fileName: e.fileName }
      }
    };
    try {
      const buf = e.media ? Buffer.from(e.media, 'base64') : null;
      if (e.type !== 'text' && !buf) {
        stored.type = 'text';
        stored.text = `${e.text ? e.text + '\n\n' : ''}⚠️ _(${e.type} was too large to keep)_`;
      }
      await sendRecovered(sock, target, stored, e.chatId, buf);
      sent++;
      await new Promise(r => setTimeout(r, 700));      // gentle pacing, avoids WhatsApp rate limits
    } catch (err) {
      console.error('[ANTIDELETE] fetch send failed:', err.message);
    }
  }
  return sent;
}
module.exports = {
  name: 'antidelete',
  aliases: ['antidel', 'deleted', 'getdeleted'],
  category: 'owner',
  description: 'Recover deleted messages into your private chat',
  usage: '.antidelete on | chat | off | fetch [n] | clear | status',
  adminOnly: true,
  storeMessage,
  handleDelete,
  async execute(sock, msg, args, extra) {
    const { reply } = extra;
    const sub = (args[0] || '').toLowerCase();
    const cfg = loadConfig();
    const globalMode = cfg['_global']?.mode || 'private';
    const statusLabel = globalMode === 'chat' ? '✅ ON — in each chat' : globalMode === 'private' ? '✅ ON — private chat' : '❌ OFF';
    const total = loadLog().length;
    if (!sub || sub === 'status') {
      return reply(`🗑️ Anti-Delete\n\nStatus: ${statusLabel}\nSaved: ${total} message(s)\n\n.antidelete on | chat | off\n.antidelete fetch [n]\n.antidelete clear`);
    }
    if (sub === 'on' || sub === 'private' || sub === 'pm') {
      cfg['_global'] = { mode: 'private' };
      saveConfig(cfg);
      return reply('🗑️ Anti-Delete is *ON* — every deleted message is sent to your private chat (this paired number).');
    }
    if (sub === 'chat') {
      cfg['_global'] = { mode: 'chat' };
      saveConfig(cfg);
      return reply('🗑️ Anti-Delete set to *Chat* — deleted messages are shown in the chat they came from.');
    }
    if (sub === 'off') {
      cfg['_global'] = { mode: 'off' };
      saveConfig(cfg);
      return reply('🗑️ Anti-Delete is *OFF*.');
    }
    if (sub === 'fetch' || sub === 'all' || sub === 'get') {
      if (!total) return reply('🗑️ No deleted messages saved yet.');
      const n = parseInt(args[1], 10);
      await reply(`🗑️ Sending ${n > 0 ? Math.min(n, total) : total} deleted message(s) to your private chat…`);
      const sent = await fetchAll(sock, n > 0 ? n : 0);
      return reply(`✅ Delivered ${sent} deleted message(s) to your private chat.`);
    }
    if (sub === 'clear') {
      saveLog([]);
      return reply('🗑️ Deleted-message history cleared.');
    }
    return reply('⚠️ Usage: .antidelete on | chat | off | fetch [n] | clear | status');
  }
};
