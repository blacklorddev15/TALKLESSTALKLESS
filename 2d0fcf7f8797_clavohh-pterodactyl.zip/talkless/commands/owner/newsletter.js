const config = require('../../config');
const CHANNEL_JID = config.newsletterJid;
module.exports = {
  name: 'newsletter',
  aliases: ['channel', 'channelinfo', 'nl'],
  category: 'owner',
  description: 'Show the configured TALKLESS XMD newsletter ID',
  usage: '.newsletter',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    const requested = (args || []).join(' ').trim();
    if (requested && requested !== CHANNEL_JID) {
      return extra.reply(`❌ Only the configured newsletter is allowed:\n${CHANNEL_JID}`);
    }
    return extra.reply(`📰 *TALKLESS XMD NEWSLETTER*\n\n🆔 ID: \`${CHANNEL_JID}\``);
  }
};
