const axios = require('axios');
const config = require('../../config');
const TIKTOK_API = 'https://api.omegatech.app/api/download/All-downloader-v2';
const TIKTOK_PATTERN = /https?:\/\/(?:www\.|vm\.|vt\.|m\.)?tiktok\.com\//i;
module.exports = [{
  name: 'tiktok',
  aliases: ['tt', 'tiktokdl'],
  category: 'media',
  description: 'Download a TikTok video',
  usage: '.tiktok <TikTok URL>',
  async execute(sock, msg, args, extra) {
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || quoted?.imageMessage?.caption || quoted?.videoMessage?.caption || '';
    const text = args.join(' ').trim() || quotedText;
    const url = text.match(/https?:\/\/[^\s]+/i)?.[0];
    if (!url || !TIKTOK_PATTERN.test(url)) {
      return extra.reply(`❌ Provide a valid TikTok URL.\nExample: ${config.prefix || '.'}tiktok https://www.tiktok.com/...`);
    }
    await extra.react?.('⏳');
    try {
      const response = await axios.get(TIKTOK_API, {
        params: { action: 'resolve', url },
        timeout: 30000
      });
      const body = response.data;
      const video = body?.success ? body.data : null;
      if (!video?.videoUrl) {
        await extra.react?.('❌');
        return extra.reply('❌ Could not resolve a downloadable video for that TikTok link.');
      }
      await sock.sendMessage(extra.from, {
        video: { url: video.videoUrl },
        mimetype: 'video/mp4',
        caption: `🎵 *TikTok Downloader*\n${video.title || ''}${video.author ? `\n👤 ${video.author}` : ''}\n\n*Downloaded by ${config.botName}*`
      }, { quoted: msg });
      await extra.react?.('✅');
    } catch (error) {
      console.error('[tiktok] Omegatech resolver error:', error.message);
      await extra.react?.('❌');
      await extra.reply('❌ TikTok download failed. The link may be private, unavailable, or expired.');
    }
  }
}];
