const pendingBulkKick = new Map();

function jidTokens(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return [];
  const [userPart, domain = ''] = raw.split('@');
  const base = userPart.split(':')[0];
  const tokens = [`jid:${domain}:${base}`];
  if (domain === 's.whatsapp.net' || !domain) {
    const digits = base.replace(/\D/g, '');
    if (digits) tokens.push(`pn:${digits}`);
  }
  if (domain === 'lid') tokens.push(`lid:${base}`);
  return tokens;
}

function participantValues(participant) {
  return [participant?.id, participant?.jid, participant?.lid, participant?.phoneNumber, participant?.pn].filter(Boolean);
}

function getTargets(metadata, sock, extra) {
  const selfTokens = new Set([
    sock.user?.id,
    sock.user?.lid,
    extra.sender,
    metadata.owner,
    metadata.creator
  ].flatMap(jidTokens));
  const participants = Array.isArray(metadata.participants) ? metadata.participants : [];
  return [...new Set(participants
    .filter(participant => {
      if (participant.admin === 'superadmin') return false;
      const tokens = participantValues(participant).flatMap(jidTokens);
      return !tokens.some(token => selfTokens.has(token));
    })
    .map(participant => participant.id || participant.jid || participant.lid || participant.phoneNumber || participant.pn)
    .filter(Boolean))];
}

module.exports = {
  name: 'kickall',
  aliases: ['removeall'],
  category: 'admin',
  description: 'Bulk-remove all other group members (paired owner only)',
  usage: '.kickall, then .kickall confirm',
  groupOnly: true,
  pairedOnly: true,
  botAdminNeeded: true,
  async execute(sock, msg, args, extra) {
    const chatId = extra.from;
    const confirmationKey = `${sock.__sessionId || extra.sender || 'paired'}:${chatId}`;
    const action = String(args[0] || '').toLowerCase();
    try {
      if (action === 'cancel') {
        pendingBulkKick.delete(confirmationKey);
        return extra.reply('Bulk removal cancelled. No members were removed.');
      }

      const pendingUntil = pendingBulkKick.get(confirmationKey) || 0;
      if (action !== 'confirm') {
        const metadata = await sock.groupMetadata(chatId);
        const targets = getTargets(metadata, sock, extra);
        if (!targets.length) return extra.reply('There are no removable members. The paired account and group creator are protected.');
        pendingBulkKick.set(confirmationKey, Date.now() + 30_000);
        return extra.reply(`⚠️ This will remove ${targets.length} other member(s) in one bulk request.\n\nReply with .kickall confirm within 30 seconds to continue, or .kickall cancel to stop.`);
      }
      if (pendingUntil < Date.now()) {
        pendingBulkKick.delete(confirmationKey);
        return extra.reply('No active confirmation. Run .kickall first to review the member count.');
      }

      pendingBulkKick.delete(confirmationKey);
      const metadata = await sock.groupMetadata(chatId);
      const targets = getTargets(metadata, sock, extra);
      if (!targets.length) return extra.reply('There are no removable members.');

      // One Baileys request with the full participant list; deliberately no per-user loop.
      const result = await sock.groupParticipantsUpdate(chatId, targets, 'remove');
      const rows = Array.isArray(result) ? result : [];
      const failed = rows.filter(row => Number(row?.status) >= 300);
      const succeeded = rows.length ? rows.length - failed.length : targets.length;
      if (!succeeded && failed.length) {
        return extra.reply(`Bulk removal failed for all ${targets.length} member(s). Check the bot's group-admin rights.`);
      }
      const partial = failed.length ? `\n${failed.length} member(s) could not be removed.` : '';
      return extra.reply(`Bulk removal sent. Removed ${succeeded} of ${targets.length} member(s). The paired account, bot, and group creator were preserved.${partial}`);
    } catch (error) {
      console.error('[kickall] Bulk removal failed:', error.message);
      return extra.reply('Bulk removal failed. Check that the bot is a group admin and try again.');
    }
  }
};
