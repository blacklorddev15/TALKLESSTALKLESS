function jidTokens(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return [];
  const [userPart, domain = ''] = raw.split('@');
  const base = userPart.split(':')[0];
  const tokens = [`jid:${domain}:${base}`];
  if (domain === 's.whatsapp.net' || !domain) {
    const digits = base.replace(/\D/g, '');
    if (digits) tokens.push(`pn:${digits}`);
  }
  if (domain === 'lid') tokens.push(`lid:${base}`);
  return tokens;
}

function valuesFor(participant) {
  return [participant?.id, participant?.jid, participant?.lid, participant?.phoneNumber, participant?.pn].filter(Boolean);
}

function samePerson(left, right) {
  const tokens = new Set(jidTokens(left));
  return jidTokens(right).some(token => tokens.has(token));
}

function mentionedOrQuoted(msg, args) {
  const context = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo;
  const mentions = context?.mentionedJid || [];
  if (mentions.length > 1) return { multiple: true };
  if (mentions[0]) return { jid: mentions[0] };
  if (context?.participant && context?.quotedMessage) return { jid: context.participant };
  const raw = String(args[0] || '').trim().replace(/^@/, '');
  const digits = raw.replace(/\D/g, '');
  if (digits.length >= 7 && digits.length <= 15) return { jid: `${digits}@s.whatsapp.net` };
  return {};
}

module.exports = {
  name: 'kick',
  aliases: ['remove', 'out'],
  category: 'admin',
  description: 'Remove one mentioned or replied-to member (paired owner only)',
  usage: '.kick @member (or reply to their message)',
  groupOnly: true,
  pairedOnly: true,
  botAdminNeeded: true,
  async execute(sock, msg, args, extra) {
    try {
      const chatId = extra.from;
      const requested = mentionedOrQuoted(msg, args);
      if (requested.multiple) return extra.reply('Choose one member at a time. Mention or reply to a single member.');
      if (!requested.jid) return extra.reply('Mention or reply to the one member you want to remove.');

      const metadata = await sock.groupMetadata(chatId);
      const participants = Array.isArray(metadata.participants) ? metadata.participants : [];
      const participant = participants.find(item => valuesFor(item).some(value => samePerson(value, requested.jid)));
      if (!participant) return extra.reply('That person is not a member of this group.');

      const botIds = [sock.user?.id, sock.user?.lid, extra.sender].filter(Boolean);
      if (valuesFor(participant).some(value => botIds.some(botId => samePerson(value, botId)))) {
        return extra.reply('The bot/paired account cannot remove itself.');
      }

      const target = participant.id || participant.jid || participant.lid || participant.phoneNumber || participant.pn;
      const result = await sock.groupParticipantsUpdate(chatId, [target], 'remove');
      const row = Array.isArray(result) ? result[0] : null;
      if (row?.status && Number(row.status) >= 300) {
        return extra.reply('WhatsApp could not remove that member. Check group roles and try again.');
      }
      const label = String(target).split('@')[0].split(':')[0];
      await sock.sendMessage(chatId, {
        text: `Removed @${label} from the group.`,
        mentions: [target]
      }, { quoted: msg });
    } catch (error) {
      console.error('[kick] Remove failed:', error.message);
      await extra.reply('Could not remove that member. Check that the bot is a group admin.');
    }
  }
};
