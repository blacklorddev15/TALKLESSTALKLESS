# TAKKLESS XMD — WhatsApp commands not responding

Repo: `github.com/jj2001887-hash/NEW-XMD` (single file: `TAKKLESS_XMD.zip` → `tele-wa-bot45/`)
Tested with the shipped code, Node 22, `@whiskeysockets/baileys@7.0.0-rc14`.

## TL;DR

The command pack itself is fine — 1116 commands load and `.ping`, `.alive`, `.menu` all reply.
The bot dies **~8 seconds after the first WhatsApp command** because one obfuscated command
module calls a logger global that this host never defines, and Node exits on the resulting
unhandled rejection. Commands sent during the restart/reconnect window are dropped, so the
bot looks "dead" on WhatsApp while Telegram keeps working.

Proven root cause: `talkless/commands/admin/chatbot.js:63` → `fetchVersion()` runs at load →

```js
global[vBRsQVzbxhAxuqbLq$NUIkpLP(0x20d)](...)   // 0x20d decodes to "log"
// TypeError: global[...] is not a function  → process exit code 1 at +8.0s
```

The TALKLESS runtime defines `global.log(msg, color)` in its own entry file. `talklessBridge.js`
mounts the pack without it, so the error path always throws.

## Evidence

| Check | Result |
|---|---|
| Load pack + dispatch `.ping` (fake socket) | `command pack mounted — 1116 commands`, replies `🔸 pong!...` / `🔹 TAKKLESS XMD Speed: 0.14 ms` |
| Require `talkless/commands/admin/chatbot.js` alone | process **exits code 1** at +8.0s, `TypeError: global[...] is not a function` |
| String table decode of `0x20d` | `GLOBAL ACCESS: log` → `global.log("[ CHATBOT ] failed to fetch version, using fallback: v1.0.0","green")` |
| `TALKLESS API endpoint` | unreachable (curl timed out) → the failing branch is always taken |
| With a `global.log` shim | survives, logs the fallback version, `ALIVE_AFTER_20S` |

Why it looks intermittent: `talklessBridge` loads the pack lazily on the **first** incoming
message, so each fresh process answers once, then dies 8s later. Whatever is sent while the
host restarts + WhatsApp reconnects (`syncFullHistory:false`, no offline queue) is lost.

## Fixes

`fixes.diff` (patch -p1) contains 4 changes. Only #1 is required to stop the crashes;
the others remove silent-kill paths and a prefix bug.

1. **`talklessBridge.js` — define the logger the pack expects (the actual fix)**
   ```js
   if (typeof global.log !== 'function') {
     global.log = (msg, color) => console.log(String(msg));
   }
   ```
2. **`helper/utils.js` — `writeJSON` must not throw.**
   `index.js:1225` calls `getWaSettings(sock.__waNum)` on *every* message, outside the
   async block and outside any try/catch. Settings write fails (read-only container disk,
   `ENOSPC`, `EACCES`) → exception thrown before `talklessBridge.handle()` → **zero** commands
   dispatched while Telegram still answers. Reproduced with an injected `EROFS`.
3. **`index.js` — guard the settings read + `unhandledRejection` handler**, so one rejected
   promise can never take down all paired sessions.
4. **`talkless/handler.js` — honour the persisted prefix.**
   `.setprefix` wrote `bot-settings.json` but the gate read the static `config.prefix`,
   so a custom prefix was ignored after every restart (and `.setprefix none` did not stick).

## Apply

```bash
cd TAKKLESS_XMD/tele-wa-bot45        # folder with index.js
patch -p1 < fixes.diff
node --check index.js               # sanity
# restart the process, then:
node diagnose.js                    # expects "0 failure(s)"
```

`diagnose.js` (drop next to `index.js`) checks writability, mode, prefix, sessions, command
count, then loads the pack in a child process and dispatches `.ping` — it reports whether
the process replied, crashed, or silently filtered the message.

Before/after on a clean extract:

```
[FAIL] dispatch  replied, then the process DIED — see the TypeError above (global.log bug)
[ OK ] dispatch  pack replied to .ping and survived the load-time checks
```

## If it still doesn't answer after patching

1. `node diagnose.js` → look at `[FAIL]` / `[WARN]` lines.
2. `talkless/database/numbers/<number>/botmode.json` — `private` means only owner/sudo get
   replies, silently. `group` / `pm` restrict by chat type.
3. Prefix must match `config.prefix` (`"."` by default) or the persisted `prefix` in
   `bot-settings.json`. Owner-only commands need the number in `talkless/config.js`
   `ownerNumber` (`254781447360`) or `SUDO_NUMBER` in `settings.js`.
4. Session restore depends on `sessions/<id>/creds.json` **and** `database/pairs.json`
   being persistent. On ephemeral PaaS disks both vanish on redeploy: the phone still shows
   "linked device" but no socket exists, so nothing responds. Mount a volume or keep the
   GitHub session sync working with a valid token.
5. On boot you should see `[TALKLESS] command pack mounted — 1116 commands` the first time you
   message the bot; if that line never appears, dispatch never reached the pack.

## Security — act on this

`settings.js` and `talkless/config.js` ship **live credentials committed in a public repo**:
Telegram bot token, GitHub PAT (`ghp_…`), Paystack secret + public key, Pterodactyl
application key, Cloudflare API tokens/zone IDs, DigitalOcean API tokens, Gemini key.
Rotate all of them, move them to `.env` (`.env.example` already exists), and keep
`settings.js` free of literals. Anyone with the repo can control your panel, VPS account,
payments and bot.

## Other observations (not patched)

- `index.js:1225` — the `prefix` variable is dead code; it costs a synchronous JSON
  read (and sometimes a write) per message. Safe to delete once #2 is in.
- `helper/listeners.js` runs before the pack: an exception in `checkAntilink` /
  `checkAntiMedia` also skips command dispatch entirely (same class of bug).
- `talkless/database/mods.json` ships placeholder empty-string moderators.
- `@whiskeysockets/baileys: "latest"` in `package.json` makes every install a lottery;
  pin the version you tested with (`7.0.0-rc14`).
